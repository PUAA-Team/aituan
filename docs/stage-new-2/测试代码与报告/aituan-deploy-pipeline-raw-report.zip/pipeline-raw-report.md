# aituan-deploy 流水线原始报告

## 运行信息

| 字段 | 值 |
| --- | --- |
| Workflow | aituan-deploy |
| Job | pipeline_raw_report |
| Job 状态 | build_and_push=success, deploy_k8s=success, deploy_compose=skipped |
| Run ID | 33239210814 |
| Run Attempt | 1 |
| Event | push |
| Ref | refs/heads/main |
| SHA | cd07d468c15e5907ce864d05d1a338c78ff35600 |
| Actor | lixu10 |
| Repository | PUAA-Team/aituan |
| Runner OS | Linux |
| 生成时间 UTC | 2026-08-29T06:52:24Z |

## 部署 / 构建关键信息

| 字段 | 值 |
| --- | --- |
| 部署目标 | k8s |
| 是否部署 | true |
| 镜像仓库 | ghcr.io/puaa-team/aituan |
| 镜像标签 | sha-cd07d46 |
| APK 名称 | 未设置 |
| API Origin | 未设置 |

## 随报告上传的原始文件

- `event-payload.json`：GitHub 触发事件原始 payload。
- `run-jobs.json`：通过 GitHub Actions API 获取的本次 run jobs 原始 JSON（若 token 权限可用）。
- `run-detail.json`：通过 GitHub Actions API 获取的本次 run 元数据原始 JSON（若 token 权限可用）。
- `git-head.txt` / `git-status.txt`：当前 checkout 的提交与工作区状态。

> 注意：报告只记录 GitHub 运行上下文和白名单字段，不主动导出 Secrets。完整逐行日志仍以 GitHub Actions 页面原生日志为准。
